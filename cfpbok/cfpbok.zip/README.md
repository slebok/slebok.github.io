## Author Information
- **Name:** Vadim Zaytsev
- **Affiliation:** University of Twente
- **Email:** vadim@grammarware.net

## Associated Paper Information
- **Title:** SLE as an Evolving Body of Knowledge: A 19-Year Comparative Analysis of Calls and Proceedings
- **Abstract:** The Software Language Engineering (SLE) community has accumulated nearly two decades of content. This content comprises not only papers as such, but also other tangible artefacts like conference descriptions, calls for papers, tools, repositories. Yet, the field’s self-description (how it positions itself to potential contributors) and its accumulated output (what the community actually produces) are rarely studied together in a reproducible, fine-grained way. This paper offers a non-judgemental inventory of SLE’s topical evolution by comparatively analysing 19 Calls for Papers (SLE 2008–2026), 6 Calls for Papers and Editorials of corresponding special issues, and 432 proceedings papers and keynotes (SLE 2008–2025), using a shared topic tagset aligned with SLEBoK-style knowledge areas. We quantify which topics are continuously emphasised, which are episodically foregrounded, and where the calls and proceedings diverge/converge among themselves and over years. We quantitatively identify topics that can be seen as core, near-core and fringe core for SLE, and compare them to neighbouring conferences. We also propose some future directions for SLEBoK. The dataset produced by this project, is released for public inspection at https://slebok.github.io/cfpbok.

## Documentation
- **Link to the repository:** https://github.com/slebok/slebok.github.io/tree/master/cfpbok
- **Deployed version:** https://slebok.github.io/cfpbok/
- While the paper covers the story about the knowledge acquisition, archeology, and analysis, this artefact contains the actual data tha was extracted from various sources, cross-referenced and re-visualised for interactive exploration
- For all goals and purposes, this is a website that be opened with a browser. There are no requirements besides having a browser, so one can open either the `index.html` directly or go to https://slebok.github.io/cfpbok/index.html
- The dataset is essentially the “body of knowledge” of the SLE conference, and is composed of “bundles”. Each bundle has its own folder, the main file is called `index.html` and has three parts: the call for papers, pieces of which are tagged as belonging to a special topic; the list of papers of which each is also tagged with topics; and the list of organisers. The third part is not important at the moment because it is never referenced in the paper. Each other file in the folder of the bundle, represents an individual paper, there are 432 of those.
- Each topic/tag also has its own page in the `tag` folder, there are 38 of those.
- Each person that has contributed to a conference, a special issue, a book or a paper, has its own profile in the `profile` folder. There are 966 of those. `profile/index.html` contains an alphabetically sorted list of all profiles.
- `.dsl` files are not important, they are an intermediate stage of generating the HTML; you can notice them committed to the linked repository but not included in the artefact submission itself to avoid distractions.
- `evidence.html` in the root folder is created specially for the purposes of evaluation of this artefact.

---

## Artefact Evaluation Environment

### System Specifications Used by Authors
- **Browser:** tested on Firefox, Chrome, Safari

### Estimated Hardware Requirements for Evaluation
- none

### Compatibility Considerations
- no VM used


## Kick-the-Tires
This section should provide a simple and quick way for the reviewer to check whether all dependencies are correctly installed and that all scripts run without errors. The goal is not to run the full evaluation but to verify that the artefact is functional.

### Steps to Perform a Quick Test
1. Open `index.html` or https://slebok.github.io/cfpbok/index.html
2. Start exploring.

## Full Evaluation
1. Open `evidence.html` or https://slebok.github.io/cfpbok/evidence.html
2. Open `paper.pdf` or the paper attached to the HotCRP submission for reference
3. Verify that statistics and summaries in the paper describe the same data presented in a much more elaborate form in the dataset.
